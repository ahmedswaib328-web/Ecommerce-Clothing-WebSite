<?php
$Valid = $_POST['txtDate'] ?? '';
$txtName = $_POST['txtName'] ?? '';
$txtDetail = $_POST['txtDetail'] ?? '';

if ($Valid && $txtName && $txtDetail) {
    $con = mysqli_connect("localhost", "root", "", "shopping");

    $sql = "INSERT INTO Offer_master (Offer, Detail, Valid) VALUES ('$txtName', '$txtDetail', '$Valid')";

    mysqli_query($con, $sql);
    mysqli_close($con);

    echo '<script type="text/javascript">alert("Offer Created Successfully"); window.location="Offers.php";</script>';
} else {
    echo '<script type="text/javascript">alert("Invalid input. Please fill all fields."); window.location="Offers.php";</script>';
}
?>