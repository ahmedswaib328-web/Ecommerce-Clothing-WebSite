  <footer class="site-footer">
    <div class="container">
      &copy; <?= date('Y') ?> Thread & Style
    </div>
  </footer>
</body>
</html>