<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: Products.php?CategoryId=' . (int)($_POST['CategoryId'] ?? 0));
    exit;
}

$itemId     = isset($_POST['ItemId'])     ? (int) $_POST['ItemId']     : 0;
$categoryId = isset($_POST['CategoryId']) ? (int) $_POST['CategoryId'] : 0;

if ($itemId <= 0) {
    echo '<script>alert("Invalid Request"); window.location="Products.php?CategoryId='.$categoryId.'";</script>';
    exit;
}

$con = mysqli_connect("localhost", "root", "", "shopping");
if (!$con) {
    echo '<script>alert("DB connection failed."); window.location="Products.php?CategoryId='.$categoryId.'";</script>';
    exit;
}

$sql = "DELETE FROM item_master WHERE ItemId = {$itemId}";
mysqli_query($con, $sql);
mysqli_close($con);

echo '<script>
        alert("Item Deleted Successfully");
        window.location="Products.php?CategoryId='.$categoryId.'";
      </script>';
exit;
