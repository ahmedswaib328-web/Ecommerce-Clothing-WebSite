<?php
if (!isset($_SESSION)) {
  session_start();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Admin Management </title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="../asset/css/main.css" />
</head>

<body>

  <?php include('Header.php'); ?>

  <div id="wrapper">

    <div id="content" class="container">

      <h2 style="margin-bottom: 20px;">Administrator Management</h2>

      <!-- User Creation Form -->
      <div class="feature-card" style="margin-bottom: 40px;">
        <h3>Create New Admin</h3>
        <form method="post" action="InsertUser.php">
          <div style="margin-bottom: 15px;">
            <label for="txtUserName">User Name:</label><br />
            <input type="text" name="txtUserName" id="txtUserName" required style="width: 100%; padding: 8px;" />
          </div>

          <div style="margin-bottom: 15px;">
            <label for="txtPassword">Password:</label><br />
            <input type="password" name="txtPassword" id="txtPassword" required style="width: 100%; padding: 8px;" />
          </div>

          <input type="submit" value="Submit" class="button-green" />




          
        </form>
      </div>

      <!-- User List -->
      <div class="feature-card">
        <h3 style = "margin-bottom: 15px;">Admin List</h3>
        <table style="width: 100%; border-collapse: collapse;">
          <thead>
            <tr style="background-color: #9cd99c;">
              <th style="padding: 10px; text-align: left;">Id</th>
              <th style="padding: 10px; text-align: left;">UserName</th>
              <th style="padding: 10px; text-align: left;">Edit</th>
              <th style="padding: 10px; text-align: left;">Delete</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $con = mysqli_connect("localhost", "root", "", "shopping");
            $sql = "SELECT * FROM admin_master";
            $result = mysqli_query($con, $sql);

            $records = mysqli_num_rows($result);

            while ($row = mysqli_fetch_array($result)) {
              $Id = $row['AdminId'];
              $UserName = $row['UserName'];
            ?>
              <tr style="border-top: 1px solid #ccc;">
                <td style="padding: 10px;"><?php echo $Id; ?></td>
                <td style="padding: 10px;"><?php echo $UserName; ?></td>
                <td style="padding: 10px;">
                  <a href="EditUser.php?AdminId=<?php echo $Id; ?>" class="btn">Edit</a>
                </td>
                <td style="padding: 10px;">
                  <a href="DeleteUser.php?AdminId=<?php echo $Id; ?>" class="btn">Delete</a>
                </td>
              </tr>
            <?php
            }
            ?>
            <tr>
              <td colspan="4" style="padding: 10px;">
                Total <strong><?php echo $records; ?></strong> Records
              </td>
            </tr>
            <?php mysqli_close($con); ?>
          </tbody>
        </table>
      </div>
    </div>

    <?php include('Right.php'); ?>
  </div>

  <?php include('Footer.php'); ?>
</body>
</html>
