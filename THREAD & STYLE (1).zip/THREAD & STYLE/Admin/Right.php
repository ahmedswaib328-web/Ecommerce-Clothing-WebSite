<div id="right-col">

  <!-- Admin Category Links -->
  <div class="feature-card" style="margin-bottom: 30px;">
    <h3 style="margin-bottom: 10px;">Manage Categories</h3>
    <ul class="side">
      <?php
      $con = mysqli_connect("localhost", "root", "", "shopping");
      $sql = "SELECT * FROM Category_Master";
      $result = mysqli_query($con, $sql);

      while ($row = mysqli_fetch_array($result)) {
          $Id = $row['CategoryId'];
          $CategoryName = $row['CategoryName'];
          echo "<li style='margin-bottom: 6px;'><a href='Products.php?CategoryId=$Id' style='color: white;'>$CategoryName</a></li>";
      }

      mysqli_close($con);
      ?>
    </ul>
  </div>

  <!-- Optional Admin Shortcuts -->
  <div class="feature-card" style="text-align: center;">
    <a href="Category.php" class="btn" style="margin-bottom: 10px;">Add New Category</a><br>
    <a href="User.php" class="btn" style="margin-bottom: 10px;">Control Admin</a><br>
    <a href="Products.php" class="btn" style="margin-bottom: 10px;">Manage Products</a><br>
    <a href="Feedback.php" class="btn">View Feedback</a>
  </div>

</div>