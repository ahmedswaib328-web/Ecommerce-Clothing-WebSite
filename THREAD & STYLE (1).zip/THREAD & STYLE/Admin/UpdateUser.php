<?php
$Id = $_POST['txtUserId'] ?? '';
$Name = $_POST['txtUserName'] ?? '';
$Password = $_POST['txtPass'] ?? '';

if ($Id && $Name && $Password) {
    $con = mysqli_connect("localhost", "root", "", "shopping");

    $sql = "UPDATE Admin_Master SET UserName='$Name', Password='$Password' WHERE AdminId=$Id";

    mysqli_query($con, $sql);
    mysqli_close($con);

    echo '<script type="text/javascript">alert("User Updated Successfully"); window.location="User.php";</script>';
} else {
    echo '<script type="text/javascript">alert("Invalid Input"); window.location="EditUser.php?AdminId=' . $Id . '";</script>';
}
?>