<?php
$Name = $_POST['txtName'] ?? '';
$Desc = $_POST['txtDesc'] ?? '';
$path1 = $_FILES["txtFile"]["name"] ?? '';

if ($Name && $Desc && $path1) {
    move_uploaded_file($_FILES["txtFile"]["tmp_name"], "../Products/" . $path1);

    $con = mysqli_connect("localhost", "root", "", "shopping");
    $sql = "INSERT INTO Category_Master (CategoryName, Description, Image) 
            VALUES ('$Name', '$Desc', '$path1')";
			
    mysqli_query($con, $sql);
    mysqli_close($con);

    echo "<script>alert('Category Inserted Successfully'); window.location='Category.php';</script>";
} else {
    echo "<script>alert('Invalid form submission'); window.location='Category.php';</script>";
}
?>