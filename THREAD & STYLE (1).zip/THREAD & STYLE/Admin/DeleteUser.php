<?php
$Id = $_GET['AdminId'] ?? '';

if ($Id) {
    $con = mysqli_connect("localhost", "root", "", "shopping");
    $sql = "DELETE FROM Admin_Master WHERE AdminId = '$Id'";
    mysqli_query($con, $sql);
    mysqli_close($con);

    echo '<script type="text/javascript">alert("User Deleted Successfully"); window.location="User.php";</script>';
} else {
    echo '<script type="text/javascript">alert("Invalid Request"); window.location="User.php";</script>';
}
?>