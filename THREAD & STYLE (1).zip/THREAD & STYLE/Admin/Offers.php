<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Manage Special Offers - Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="../asset/css/main.css" />
</head>

<body>

  <?php include('Header.php'); ?>

  <div id="wrapper">

    <div id="content" class="container">

      <h2 style="margin-bottom: 20px;">Manage Special Offers</h2>

      <!-- Offer Creation Form -->
      <div class="feature-card" style="margin-bottom: 40px;">
        <h3>Create New Offer</h3>
        <form method="post" action="InsertOffer.php">
          <div style="margin-bottom: 15px;">
            <label for="txtName">Offer Name:</label><br />
            <input type="text" name="txtName" id="txtName" required style="width: 100%; padding: 8px;" />
          </div>
          <div style="margin-bottom: 15px;">
            <label for="txtDetail">Offer Detail:</label><br />
            <textarea name="txtDetail" id="txtDetail" rows="3" required style="width: 100%; padding: 8px;"></textarea>
          </div>
          <div style="margin-bottom: 15px;">
            <label for="txtDate">Offer Valid Up to:</label><br />
            <input type="date" name="txtDate" id="txtDate" required style="width: 100%; padding: 8px;" />
          </div>
          <input type="submit" value="Create Offer" class="button-green" />
        </form>
      </div>

      <!-- Offers List -->
      <div class="feature-card">
        <h3 style = "margin-bottom: 15px;">Special Offers</h3>
        <table style="width: 100%; border-collapse: collapse;">
          <thead>
            <tr style="background-color: #9cd99c;">
              <th style="padding: 10px; text-align: left;">Id</th>
              <th style="padding: 10px; text-align: left;">Offer</th>
              <th style="padding: 10px; text-align: left;">Detail</th>
              <th style="padding: 10px; text-align: left;">Valid Upto</th>
              <th style="padding: 10px; text-align: left;">Delete</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $con = mysqli_connect("localhost", "root", "", "shopping");
            $sql = "SELECT * FROM Offer_Master";
            $result = mysqli_query($con, $sql);

            $records = mysqli_num_rows($result);

            while ($row = mysqli_fetch_array($result)) {
                $Id = $row['OfferId'];
                $Offer = $row['Offer'];
                $Detail = $row['Detail'];
                $Valid = $row['Valid'];
            ?>
              <tr style="border-top: 1px solid #ccc;">
                <td style="padding: 10px;"><?php echo $Id; ?></td>
                <td style="padding: 10px;"><?php echo $Offer; ?></td>
                <td style="padding: 10px;"><?php echo $Detail; ?></td>
                <td style="padding: 10px;"><?php echo $Valid; ?></td>
                <td style="padding: 10px;">
                  <a href="DeleteOffer.php?OfferId=<?php echo $Id; ?>" class="btn">Delete</a>
                </td>
              </tr>
            <?php
            }
            ?>
            <tr>
              <td colspan="5" style="padding: 10px;">
                Total <strong><?php echo $records; ?></strong> Records
              </td>
            </tr>
            <?php mysqli_close($con); ?>
          </tbody>
        </table>
      </div>

    </div>

    <?php include('Right.php'); ?>
    <div style="clear: both;"></div>
  </div>
  <?php include('Footer.php'); ?>
</body>
</html>