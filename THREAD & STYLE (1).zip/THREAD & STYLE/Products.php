<?php
require_once('Connections/shop.php');
session_start();

function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "")
{
  $theValue = stripslashes($theValue);
  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$colname_Recordset1 = "-1";
if (isset($_GET['CategoryId'])) {
  $colname_Recordset1 = $_GET['CategoryId'];
}

$query_Recordset1 = sprintf("SELECT ItemName, `Description`, `Size`, Image, Price, Discount, Total FROM item_master WHERE CategoryId = %s", GetSQLValueString($colname_Recordset1, "int"));
$Recordset1 = mysqli_query($shop, $query_Recordset1) or die(mysqli_error());

$query_Recordset2 = "SELECT ItemName, `Description`, `Size`, Image, Price, Discount, Total FROM item_master";
$Recordset2 = mysqli_query($shop, $query_Recordset2) or die(mysqli_error());
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8" />
  <title>Online Cloth Shopping</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="asset/css/main.css" />
</head>

<body>

  <?php include('Header.php'); ?>

  <div id="wrapper">

    <div id="content" class="container">

      <h2 style="margin: 40px 0; text-align: center;">Products</h2>

      <section class="features">
        <?php
        if (isset($_GET['CategoryId'])) {
          while ($row = mysqli_fetch_assoc($Recordset1)) {
        ?>
            <div class="feature-card">
              <img src="Products/<?php echo $row['Image']; ?>" alt="<?php echo $row['ItemName']; ?>" />
              <h3><?php echo $row['ItemName']; ?></h3>
              <p><?php echo $row['Description']; ?></p>
              <p><strong>Size:</strong> <?php echo $row['Size']; ?></p>
              <p><strong>Price:</strong> BDT <?php echo $row['Price']; ?></p>
              <p><strong>Discount:</strong> <?php echo $row['Discount']; ?>%</p>
              <p><strong>Total:</strong> BDT <?php echo $row['Total']; ?></p>
            </div>
          <?php
          }
        } else {
          if (mysqli_num_rows($Recordset2) > 0) {
            while ($row = mysqli_fetch_assoc($Recordset2)) {
          ?>
              <div class="feature-card">
                <img src="Products/<?php echo $row['Image']; ?>" alt="<?php echo $row['ItemName']; ?>" />
                <h3><?php echo $row['ItemName']; ?></h3>
                <p><?php echo $row['Description']; ?></p>
                <p><strong>Size:</strong> <?php echo $row['Size']; ?></p>
                <p><strong>Price:</strong> BDT <?php echo $row['Price']; ?></p>
                <p><strong>Discount:</strong> <?php echo $row['Discount']; ?>%</p>
                <p><strong>Total:</strong> BDT <?php echo $row['Total']; ?></p>
              </div>
        <?php
            }
          } else {
            echo "<p style='text-align:center;'>No Data Available</p>";
          }
        }
        ?>
      </section>
    </div>
    <?php include('Right.php'); ?>
  </div>
  <?php include('Footer.php'); ?>

  <?php
  mysqli_free_result($Recordset1);
  mysqli_free_result($Recordset2);
  mysqli_close($shop);
  ?>

</body>

</html>
