<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Order History - Online Clothing Store</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../asset/css/main.css">
</head>
<body>

<?php include('Header.php'); ?>

<div id="wrapper">
  <div id="content" class="container">

    <h2 style="color:#9cd99c; margin-bottom: 20px;">Welcome <?php echo $_SESSION['Name']; ?> — Your Order History</h2>

    <section class="features" style="flex-direction: column; gap: 20px;">
      <?php
      $con = mysqli_connect("localhost", "root", "", "shopping");

      $sql = "SELECT shopping_cart_final.CustomerId, shopping_cart_final.ItemName, shopping_cart_final.Quantity, shopping_cart_final.Price, shopping_cart_final.Total, item_master.Image, item_master.Size
              FROM shopping_cart_final, item_master
              WHERE item_master.ItemName = shopping_cart_final.ItemName
              AND shopping_cart_final.CustomerId = " . $_SESSION['ID'];

      $result = mysqli_query($con, $sql);

      while ($row = mysqli_fetch_array($result)) {
          $ItemName = $row['ItemName'];
          $Quantity = $row['Quantity'];
          $Price = $row['Price'];
          $Total = $row['Total'];
          $Size = $row['Size'];
          $Image = $row['Image'];
      ?>
      <div class="feature-card" style="display: flex; justify-content: space-between; align-items: center;">
        <div>
          <h3><?php echo $ItemName; ?></h3>
          <p><strong>Size:</strong> <?php echo $Size; ?></p>
          <p><strong>Quantity:</strong> <?php echo $Quantity; ?></p>
          <p><strong>Price:</strong> <?php echo $Price; ?> Tk</p>
          <p><strong>Total:</strong> <?php echo $Total; ?> Tk</p>
        </div>
        <div>
          <img src="../Products/<?php echo $Image; ?>" width="120" height="120" alt="<?php echo $ItemName; ?>" style="border-radius: 10px;">
        </div>
      </div>
      <?php } ?>
    </section>

  </div>

  <?php include('Right.php'); ?>
</div>

<?php include('Footer.php'); ?>

</body>
</html>