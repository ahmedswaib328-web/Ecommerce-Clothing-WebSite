<?php
session_start();
require_once('../Connections/shop.php');

// Get category ID from URL, default to -1 if not set
$categoryId = isset($_GET['CategoryId']) ? intval($_GET['CategoryId']) : -1;

// Fetch items based on selected category
$queryItems = "SELECT ItemId, ItemName, Description, Size, Image, Price, Discount, Total FROM item_master WHERE CategoryId = $categoryId";
$resultItems = mysqli_query($shop, $queryItems);

// If no category is selected, fetch all items
if ($categoryId == -1) {
  $queryAllItems = "SELECT ItemId, ItemName, Description, Size, Image, Price, Discount, Total FROM item_master";
  $resultAllItems = mysqli_query($shop, $queryAllItems);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Products - Customer</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="../asset/css/main.css" />
</head>

<body>

  <?php include('Header.php'); ?>

  <div id="wrapper">
    <div id="content" class="container">

      <h2 style="margin-bottom: 20px;">Welcome <?php echo ($_SESSION['Name']); ?></h2>

      <!-- Product List Table -->
      <div >
        <table style="width: 100%; border-collapse: collapse; margin-top: 15px;">
          <thead style="background-color: #9cd99c;">
            <tr>
              <!--<th style="padding: 10px;">Code</th> -->
              <th style="padding: 10px;">Item Name</th>
              <th style="padding: 10px;">Description</th>
              <th style="padding: 10px;">Size</th>
              <th style="padding: 10px;">Image</th>
              <th style="padding: 10px;">Price</th>
              <th style="padding: 10px;">Discount %</th>
              <th style="padding: 10px;">Total</th>
              <th style="padding: 10px;">Cart</th>
            </tr>
          </thead>
          <tbody>
            <?php
            if ($categoryId != -1 && mysqli_num_rows($resultItems) > 0) {
              while ($item = mysqli_fetch_assoc($resultItems)) {
            ?>
                <tr style="border-top: 1px solid #ccc;">
                  <!--<td style="padding: 10px;"><?php echo $item['ItemId']; ?></td>-->
                  <td style="padding: 10px;"><?php echo  ($item['ItemName']); ?></td>
                  <td style="padding: 10px;"><?php echo  ($item['Description']); ?></td>
                  <td style="padding: 10px;"><?php echo  ($item['Size']); ?></td>
                  <td style="padding: 10px;">
                    <img src="../Products/<?php echo  ($item['Image']); ?>" height="125px" width="125px" alt="Product Image" />
                  </td>
                  <td style="padding: 10px;"><?php echo number_format($item['Price'] , 2); ?></td>
                  <td style="padding: 10px;"><?php echo number_format($item['Discount']); ?></td>
                  <td style="padding: 10px;"><?php echo number_format($item['Total'], 2); ?></td>
                  <td style="padding: 10px;">
                    <a href="InsertCart.php?ItemId=<?php echo $item['ItemId']; ?>"><img src="img/shopping-cart.png" class="icon-small"  alt="Add to Cart" /></a>
                  </td>
                </tr>
              <?php
              }
            } else if (mysqli_num_rows($resultAllItems) > 0) {
              while ($item = mysqli_fetch_assoc($resultAllItems)) {
              ?>
                <tr style="border-top: 1px solid #ccc;">
                 <!-- <td style="padding: 10px;"><?php echo $item['ItemId']; ?></td> -->
                  <td style="padding: 10px;"><?php echo  ($item['ItemName']); ?></td>
                  <td style="padding: 10px;"><?php echo  ($item['Description']); ?></td>
                  <td style="padding: 10px;"><?php echo  ($item['Size']); ?></td>
                  <td style="padding: 10px;">
                    <img src="../Products/<?php echo  ($item['Image']); ?>" height="125px" width="125px" alt="Product Image" />
                  </td>
                  <td style="padding: 10px;"><?php echo number_format($item['Price'], 2); ?></td>
                  <td style="padding: 10px;"><?php echo number_format($item['Discount']); ?></td>
                  <td style="padding: 10px;"><?php echo number_format($item['Total'], 2); ?></td>
                  <td style="padding: 10px;">
                    <a href="InsertCart.php?ItemId=<?php echo $item['ItemId']; ?>"><img src="img/shopping-cart.png" class="icon-small"  alt="Add to Cart" /></a>
                  </td>
                </tr>
            <?php
              }
            }
            ?>
          </tbody>
        </table>
      </div>

    </div> 
    <?php include('Right.php'); ?>
  </div> 
  <?php include('Footer.php'); ?>
</body>
</html>

<?php
mysqli_free_result($resultItems);
mysqli_free_result($resultAllItems);
?>
