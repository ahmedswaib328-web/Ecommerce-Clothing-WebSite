<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Product Categories - Online Clothing Store</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../asset/css/main.css">
</head>
<body>

<?php include('Header.php'); ?>

<div id="wrapper">
  <div id="content" class="container">
    <h2 style="margin-bottom: 20px;">Welcome <?php echo $_SESSION['Name']; ?> — Product Categories</h2>

    <section class="features">
      <?php
      $con = mysqli_connect("localhost", "root", "", "shopping");
      $sql = "SELECT * FROM Category_Master";
      $result = mysqli_query($con, $sql);

      while ($row = mysqli_fetch_array($result)) {
          $Id = $row['CategoryId'];
          $CategoryName = $row['CategoryName'];
          $Description = $row['Description'];
          $Image = $row['Image'];
      ?>
      <div class="feature-card">
        <img src="../Products/<?php echo $Image; ?>" alt="<?php echo $CategoryName; ?>">
        <h3><?php echo $CategoryName; ?></h3>
        <p><?php echo $Description; ?></p>
        <a href="Products.php?CategoryId=<?php echo $Id; ?>" class="btn">View Products</a>
      </div>
      <?php } ?>
    </section>

  </div>

  <?php include('Right.php'); ?>
</div>

<?php include('Footer.php'); ?>

</body>
</html>