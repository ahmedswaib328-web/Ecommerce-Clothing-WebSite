<?php
session_start();

$Id = $_GET['Id'];

// Step 1: Get item info
$con = mysqli_connect("localhost", "root", "", "shopping");

$sql = "SELECT * FROM Item_Master WHERE ItemId = $Id";
$result = mysqli_query($con, $sql);

while ($row = mysqli_fetch_array($result)) {
    $Id = $row['ItemId'];
    $Name = $row['ItemName'];
    $Description = $row['Description'];
    $Size = $row['Size'];
    $Price = $row['Price'];
    $Discount = $row['Discount'];
    $Total = $row['Total'];
    $Image = $row['Image'];
}
mysqli_close($con);

// Step 2: Prepare and insert into Shopping_Cart
$Qty = $_POST['txtQty'];
$CID = $_SESSION['ID'];
$ODate = date('y/m/d');
$Net = $Total * $Qty;

$con = mysqli_connect("localhost", "root", "", "shopping");

$sql = "INSERT INTO Shopping_Cart (CustomerId, ItemName, Quantity, Price, Total, OrderDate)
        VALUES ($CID, '$Name', $Qty, $Total, $Net, '$ODate')";
mysqli_query($con, $sql);
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Item Added</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../asset/css/main.css">
</head>
<body>

<script>
  alert("Item Added To the cart");
  window.location = 'Products.php';
</script>

</body>
</html>