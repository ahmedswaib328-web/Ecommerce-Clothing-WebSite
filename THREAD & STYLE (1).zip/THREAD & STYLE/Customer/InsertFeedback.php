<?php
if (!isset($_SESSION)) {
    session_start();
}

$FeedBack = $_POST['txtFeedback'] ?? '';
$FDate = date('Y-m-d');
$Id = $_SESSION['ID'];

$con = mysqli_connect("localhost", "root", "", "shopping");

$sql = "INSERT INTO feedback_master (CustomerId, Feedback, Date)
        VALUES ('$Id', '$FeedBack', '$FDate')";

mysqli_query($con, $sql);
mysqli_close($con);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Feedback Submitted</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="asset/css/main.css">
</head>
<body>

<script>
  alert("Feedback Given Successfully");
  window.location = 'Feedback.php';
</script>

</body>
</html>