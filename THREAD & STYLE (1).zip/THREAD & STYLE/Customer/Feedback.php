<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Feedback - Online Clothing Store</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../asset/css/main.css">
</head>
<body>

<?php include('Header.php'); ?>

<div id="wrapper">
  <div id="content" class="container">

    <h2 style="margin-bottom: 20px;">Hello <?php echo $_SESSION['Name']; ?> — Leave Your Feedback</h2>

    <div class="feature-card">
      <form action="InsertFeedback.php" method="post">
        <label for="txtFeedback"><strong>Your Feedback:</strong></label>
        <textarea name="txtFeedback" id="txtFeedback" rows="6" style="width:100%; margin-top:10px; padding:10px; border-radius:8px; border:1px solid #ccc;"></textarea>
        
        <input type="submit" value="Submit Feedback" class="button-green" style="margin-top: 15px;">
      </form>
    </div>

  </div>

  <?php include('Right.php'); ?>
</div>

<?php include('Footer.php'); ?>

</body>
</html>