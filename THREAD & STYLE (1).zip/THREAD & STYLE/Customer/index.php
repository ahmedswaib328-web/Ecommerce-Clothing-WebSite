<?php
if (!isset($_SESSION)) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>THREAD & STYLE</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../asset/css/main.css">
</head>
<body>

<?php include('Header.php'); ?>

<div id="wrapper">
  <div id="content" class="container">

    <!-- Hero Section -->
    <section class="hero">
      <div class="hero-text">
        <h1>Welcome <?php echo $_SESSION['Name']; ?></h1>
        <p>Discover the perfect blend of style and comfort with Thread & Style. Our collection is designed to make you feel confident and at ease, every day.</p>
        <a href="Products.php" class="btn">Shop Now</a>
      </div>
      <div class="hero-img">
        <img src="img/user.png" alt="Hero Image">
      </div>
    </section>
  </div>
  <?php include('Right.php'); ?>
</div>
<?php include('Footer.php'); ?>
</body>
</html>
