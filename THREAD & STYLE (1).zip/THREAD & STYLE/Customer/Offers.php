<?php
session_start();
require_once('../Connections/shop.php');

$queryOffers = "SELECT * FROM Offer_Master";
$resultOffers = mysqli_query($shop, $queryOffers);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <title>Offers - Customer</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="../asset/css/main.css" />
</head>

<body>

  <?php include('Header.php'); ?>
  <div id="wrapper">

    <div id="content" class="container">

      <h1 style="margin-bottom: 20px;">Welcome, <?php echo ($_SESSION['Name']); ?></h1>

      <h2 style="text-align: center;">Available Offers</h2>

      <section class="features">
        <?php
        if (mysqli_num_rows($resultOffers) > 0) {
          while ($row = mysqli_fetch_assoc($resultOffers)) {
        ?>
            <div class="feature-card">
              <h3><?= ($row['Offer']) ?></h3>
              <p><?= ($row['Detail']) ?></p>
              <small>Valid Until: <?= ($row['Valid']) ?></small>
            </div>
        <?php
          }
        } else {
          echo "<p>No offers available at the moment.</p>";
        }
        ?>
      </section>

      <!--<h2 style="margin: 50px 0 20px; text-align: center;">Trending Products</h2>-->

      <section class="features">
        <?php
        $con = mysqli_connect("localhost", "root", "", "shopping");
        $sql = "SELECT * FROM Category_Master";
        $result = mysqli_query($con, $sql);

        while ($row = mysqli_fetch_array($result)) {
          $Id = $row['CategoryId'];
          $CategoryName = $row['CategoryName'];
          $Description = $row['Description'];
          $Image = $row['Image'];
        ?>
          <div class="feature-card">
            <img src="../Products/<?php echo $Image; ?>" alt="<?php echo $CategoryName; ?>">
            <h3><?php echo $CategoryName; ?></h3>
            <p><?php echo $Description; ?></p>
            <a href="Products.php?CategoryId=<?php echo $Id; ?>" class="btn">View Products</a>
          </div>
        <?php } ?>
      </section>

    </div>
    <?php include('Right.php'); ?>
  </div>
  <?php include('Footer.php'); ?>
</body>

</html>
<?php
mysqli_free_result($resultOffers);
?>