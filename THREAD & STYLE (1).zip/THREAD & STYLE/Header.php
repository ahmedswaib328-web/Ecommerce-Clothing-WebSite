<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>THREAD & STYLE</title>
  <link rel="stylesheet" href="asset/css/main.css">
</head>

<body>
  <header class="site-header" >
    <div class="container header-flex">
      <a href="index.php" class="logo">THREAD & STYLE</a>
      <nav class="site-nav">
        <a href="index.php">Home</a>
        <a href="Category.php">Categories</a>
        <a href="Offers.php">Offers</a>
        <a href="Register.php">Register</a>
        <a href="Contact.php">Contact</a>
      </nav>
    </div>
  </header>