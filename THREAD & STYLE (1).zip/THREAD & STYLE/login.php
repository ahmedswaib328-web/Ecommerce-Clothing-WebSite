<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $UserName = trim($_POST['txtUserName'] ?? '');
    $Password = trim($_POST['txtPassword'] ?? '');
    $UserType = $_POST['rdType'] ?? '';

    $con = mysqli_connect("localhost", "root", "", "shopping");

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $UserName = mysqli_real_escape_string($con, $UserName);
    $Password = mysqli_real_escape_string($con, $Password);

    if ($UserType === "Admin") {
        $query = "SELECT * FROM Admin_Master WHERE UserName = '$UserName' AND Password = '$Password'";
    } elseif ($UserType === "Customer") {
        $query = "SELECT * FROM Customer_Registration WHERE UserName = '$UserName' AND Password = '$Password'";
    } else {
        echo '<script>alert("Invalid user type selected."); window.location="index.php";</script>';
        exit;
    }

    $result = mysqli_query($con, $query);

    if ($result && mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);

        if ($UserType === "Admin") {
            header("Location: Admin/index.php");
        } else {
            $_SESSION['ID'] = $row['CustomerId'];
            $_SESSION['Name'] = $row['CustomerName'];
            header("Location: Customer/index.php");
        }
        exit;
    } else {
        echo '<script>alert("Wrong Username or Password"); window.location="index.php";</script>';
        exit;
    }

    mysqli_close($con);
} else {
    header("Location: index.php");
    exit;
}
?>