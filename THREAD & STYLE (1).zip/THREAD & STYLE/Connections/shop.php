<?php 
$hostname_shop = "localhost";
$database_shop = "shopping";
$username_shop = "root";
$password_shop = "";
$shop = mysqli_connect($hostname_shop, $username_shop, $password_shop, $database_shop) 
    or trigger_error(mysqli_connect_error(), E_USER_ERROR);
mysqli_set_charset($shop, 'utf8'); // optional
?>
