<?php
include('Header.php');

$con = mysqli_connect("localhost", "root", "", "shopping");
$sql = "SELECT * FROM Category_Master";
$result = mysqli_query($con, $sql);
?>

<div id="wrapper">
  <div id="content" class="container">
    <h2 style=" margin-bottom: 20px;">Product Categories</h2>
    <section class="features">
      <?php while ($row = mysqli_fetch_array($result)): ?>
        <div class="feature-card">
          <img src="Products/<?= ($row['Image']) ?>" alt="<?= ($row['CategoryName']) ?>">
          <h3><?= ($row['CategoryName']) ?></h3>
          <p><?= ($row['Description']) ?></p>
          <a href="Products.php?CategoryId=<?= $row['CategoryId'] ?>" class="btn" style="margin-top: 10px; display: inline-block;">View Products</a>
        </div>
      <?php endwhile; ?>
    </section>
  </div>

  <?php include('Right.php'); ?>
</div>

<?php
mysqli_close($con);
include('Footer.php');
?>