<?php include('Header.php'); ?>

<div id="wrapper">
  <div id="content" class="container">
    <h2 style="margin-bottom: 20px;">Contact Us</h2>

    <section class="features">
      <div class="feature-card">
        <h3>Head Office</h3>
        <p>Planet SR<br>Near Jashore Zilla School Road<br>Jashore - 3500</p>
        <p>Phone: 01718985058</p>
        <p>Email: iftakharulislam909@gmail.com</p>
      </div>
      <div class="feature-card">
        <h3>Branch Office</h3>
        <p>BN Mall<br>Block D, Road 8, Mohakhali<br>Dhaka - 1212</p>
        <p>Phone: 01600112233</p>
        <p>Email: janinahmed@gmail.com</p>
      </div>
      <div class="feature-card">
        <h3>Branch Office</h3>
        <p>BN Mall<br>Block h, Road 4, Badda<br>Dhaka - 1212</p>
        <p>Phone: 01700112233</p>
        <p>Email: mdinam@gmail.com</p>
      </div>
    </section>
  </div>


</div>

<?php include('Footer.php'); ?>