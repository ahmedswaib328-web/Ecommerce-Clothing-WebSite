<?php include('Header.php'); ?>

<main class="container">
	<h2>Add New Product</h2>

	<?php
	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
		$Name = $_POST['txtName'];
		$Address = $_POST['txtAddress'];
		$City = $_POST['cmbCity'];

		$Email = $_POST['txtEmail'];
		$Mobile = $_POST['txtMobile'];
		$Gender = $_POST['rdGender'];
		$BirthDate = $_POST['txtDate'];

		$UserName = $_POST['txtUserName'];
		$Password = $_POST['txtPassword'];


		$con = mysqli_connect("localhost", "root", "", "shopping");

		$sql = "insert into customer_registration(CustomerName,Address,City,Email,Mobile,Gender,BirthDate,UserName,Password) values('" . $Name . "','" . $Address . "','" . $City . "','" . $Email . "'," . $Mobile . ",'" . $Gender . "','" . $BirthDate . "','" . $UserName . "','" . $Password . "')";

		mysqli_query($con, $sql);

		mysqli_close($con);

		echo '<script type="text/javascript">alert("Registration Completed Succesfully");window.location=\'index.php\';</script>';
	}
	?>

	<form action="Insert.php" method="post" enctype="multipart/form-data">
		<label for="name">Product Name</label>
		<input id="name" name="name" type="text" required>

		<label for="price">Price</label>
		<input id="price" name="price" type="number" step="0.01" required>

		<label for="image">Image</label>
		<input id="image" name="image" type="file" accept="image/*" required>

		<button type="submit" class="btn">Create Product</button>
	</form>
</main>

<?php include('Footer.php'); ?>