<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>THREAD & STYLE - Register</title>
  <link rel="stylesheet" href="asset/css/main.css">
</head>
<body>

<?php include('Header.php'); ?>

<div id="wrapper">
  <div id="content">
    <h2 style="margin-bottom: 20px;">New User Registration</h2>

    <div class="feature-card" style="max-width: 100%; margin-bottom: 40px;">
      <form id="registerForm" action="insert.php" method="post" enctype="multipart/form-data" style="display: grid; gap: 20px;">
        <div style="margin-bottom: 15px;">
          <label for="txtName">Customer Name</label><br>
          <input type="text" name="txtName" id="txtName" required style="width: 100%; padding: 8px;" />
          <span class="error" id="txtNameError"></span>
        </div>

        <div style="margin-bottom: 15px;">
          <label for="txtAddress">Address</label><br>
          <textarea name="txtAddress" id="txtAddress" rows="3" required style="width: 100%; padding: 8px;"></textarea>
          <span class="error" id="txtAddressError"></span>
        </div>

        <div style="margin-bottom: 15px;">
          <label for="cmbCity">City</label><br>
          <select name="cmbCity"  class="button-green" id="cmbCity" required style="width: 100%; padding: 8px;">
           <option value="">Select City</option>
            <option value="Dhaka">Dhaka</option>
            <option value="Chittagong">Chittagong</option>
            <option value="Khulna">Khulna</option>
            <option value="Cumilla">Cumilla</option>
            <option value="Sylhet">Sylhet</option>
            <option value="Rajshahi">Rajshahi</option>
            <option value="Barisal">Barisal</option>
            <option value="Rangpur">Rangpur</option>
            <option value="Mymensingh">Mymensingh</option>
            <option value="Jessore">Jessore</option>
            <option value="Tangail">Tangail</option>
            <option value="Bogra">Bogra</option>
            <option value="Pabna">Pabna</option>
            <option value="Narayanganj">Narayanganj</option>


          </select>
        </div>

        <div style="margin-bottom: 15px;">
          <label for="txtEmail">Email ID</label><br>
          <input type="email" name="txtEmail" id="txtEmail"  required style="width: 100%; padding: 8px;"/>
          <span class="error" id="txtEmailError"></span>
        </div>

        <div style="margin-bottom: 15px;">
          <label for="txtMobile">Mobile Number</label><br>
          <input type="tel" name="txtMobile" id="txtMobile" pattern="[0-9]{10}" required style="width: 100%; padding: 8px;"/>
          <span class="error" id="txtMobileError"></span>
        </div>

        <div>
          <label for="rdGender">Gender</label><br>
          <select name="rdGender" class="button-green" id="rdGender" required style="width: 100%; padding: 8px;">
            <option value="">Select</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
          </select>
        </div>

        <div>
          <label for="txtDate">Birth Date</label><br>
          <input type="date" class="button-green" name="txtDate" id="txtDate" required style="width: 100%; padding: 8px;" />
        </div>

        <div>
          <label for="txtUserName">User Name</label><br>
          <input type="text" name="txtUserName" id="txtUserName" required style="width: 100%; padding: 8px;"/>
        </div>

        <div>
          <label for="txtPassword">Password</label><br>
          <input type="password" name="txtPassword" id="txtPassword" required style="width: 100%; padding: 8px;"/>
        </div>

        <div style="text-align: right;">
          <input type="submit" value="Register" class="button-green" />
        </div>
      </form>
    </div>

  </div>

  <?php include('Right.php'); ?>
</div>
<script src="asset/js/register_validation.js"></script>
<?php include('Footer.php'); ?>

</body>
</html>